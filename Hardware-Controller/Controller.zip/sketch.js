let bugs = [];
let score = 0;
let timer = 30;
let bugSprite;
let gameOver = false;
let gameStarted = false;
let frameIndex = 0;
let frameDelay = 10;
let frameCounter = 0;
let speedMultiplier = 1;
let restartButton;

let port;
let connectButton;
let serialBuffer = "";

let cursorX = 300;
let cursorY = 200;
let buttonPressed = false;
let prevButtonState = 1;
let cursorImg;

function preload() {
  bugSprite = loadImage('bugsprite.png');
  cursorImg = loadImage('cursor.png');
}

function setup() {
  createCanvas(600, 400);

  let startButton = createButton('Start Game');
  startButton.position(width / 2 - 40, height / 2);
  startButton.mousePressed(() => {
    gameStarted = true;
    startButton.hide();
    setInterval(() => { if (timer > 0) timer--; }, 1000);
    for (let i = 0; i < 5; i++) {
      bugs.push(new Bug(random(width), random(height), random([-1, 1]), random([-1, 1])));
    }
  });

  connectButton = createButton('Connect Arduino');
  connectButton.position(20, 20);
  connectButton.mousePressed(connect);
  port = createSerial();
}

function draw() {
  background(220);

  if (!gameStarted) {
    textSize(32);
    fill("black");
    textAlign(CENTER, CENTER);
    text('Bug Squish Game', width / 2, height / 2 - 50);
    textSize(18);
    text('Click the button to start!', width / 2, height / 2 - 20);
    return;
  }

  if (timer <= 0) {
    gameOver = true;
    textSize(32);
    fill("black");
    textAlign(CENTER, CENTER);
    text('Game Over!', width / 2, height / 2);
    text(`Score: ${score}`, width / 2, height / 2 + 40);
    textSize(18);
    text("Click the button to restart!", width / 2, height / 2 + 80);
    if (!restartButton) {
      restartButton = createButton('Restart');
      restartButton.position(width / 2 - 40, height / 2 + 110);
      restartButton.mousePressed(() => {
        resetGame();
      });
    }
    return;
  }

  frameCounter++;
  if (frameCounter >= frameDelay) {
    frameIndex = (frameIndex + 1) % 2;
    frameCounter = 0;
  }

  for (let bug of bugs) {
    bug.move();
    bug.display();
  }

  fill(0);
  textSize(16);
  text(`Score: ${score}`, 40, 20);
  text(`Time: ${timer}`, 40, 40);

  readJoystick();
  image(cursorImg, cursorX, cursorY, 42, 70);

  if (buttonPressed) {
    trySquish(cursorX, cursorY);
    buttonPressed = false;
  }
}

function mousePressed() {
  if (!gameStarted || gameOver) return;
  trySquish(mouseX, mouseY);
}

function trySquish(mx, my) {
  let bugClicked = false;
  for (let bug of bugs) {
    if (bug.isClicked(mx, my) && !bug.squished) {
      bug.squish();
      score++;
      speedMultiplier += 0.1;
      bugs.push(new Bug(random(width), random(height), random([-1, 1]), random([-1, 1])));
      bugClicked = true;
    }
  }
}

function resetGame() {
  gameOver = false;
  gameStarted = true;
  score = 0;
  timer = 30;
  bugs = [];
  speedMultiplier = 1;
  restartButton.remove();
  restartButton = null;
  for (let i = 0; i < 5; i++) {
    bugs.push(new Bug(random(width), random(height), random([-1, 1]), random([-1, 1])));
  }
}

class Bug {
  constructor(x, y, dx, dy) {
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.size = 40;
    this.squished = false;
    this.rotation = atan2(dy, dx) + PI / 2;
  }

  move() {
    if (!this.squished) {
      this.x += this.dx * 2 * speedMultiplier;
      this.y += this.dy * 2 * speedMultiplier;
      this.rotation = atan2(this.dy, this.dx) + PI / 2;

      if (this.x < 0 || this.x > width) this.dx *= -1;
      if (this.y < 0 || this.y > height) this.dy *= -1;
    }
  }

  display() {
    push();
    translate(this.x, this.y);
    rotate(this.rotation);
    if (this.squished) {
      image(bugSprite, -this.size / 2, -this.size / 2, this.size, this.size, 0, 32, 32, 32);
    } else {
      image(bugSprite, -this.size / 2, -this.size / 2, this.size, this.size, frameIndex * 32, 0, 32, 32);
    }
    pop();
  }

  isClicked(mx, my) {
    return dist(mx, my, this.x, this.y) < this.size / 2;
  }

  squish() {
    this.squished = true;
  }
}

function readJoystick() {
  while (port.available() > 0) {
    let char = port.read();
    if (char === '\n') {
      let data = serialBuffer.trim();
      serialBuffer = "";

      if (data.includes(",")) {
        let parts = data.split(",").map(Number);
        if (parts.length === 3 && parts.every(n => !isNaN(n))) {
          let [yRaw, xRaw, buttonState] = parts; // ✅ FIXED ORDER
          console.log(`xRaw: ${xRaw}, yRaw: ${yRaw}, button: ${buttonState}`);

          let xNorm = map(xRaw, 0, 1023, -1, 1);
          let yNorm = map(yRaw, 0, 1023, -1, 1);

          const deadzone = 0.1;
          if (abs(xNorm) < deadzone) xNorm = 0;
          if (abs(yNorm) < deadzone) yNorm = 0;

          const speed = 8;
          cursorX += xNorm * speed;
          cursorY += yNorm


function connect() {
  port.open('Arduino', 9600);
}
